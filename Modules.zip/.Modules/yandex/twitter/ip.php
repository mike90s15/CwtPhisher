<?php

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
  $ipaddress = $_SERVER['HTTP_CLIENT_IP']."\r\n";
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
  $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR']."\r\n";
} else {
  $ipaddress = $_SERVER['REMOTE_ADDR']."\r\n";
}

$fp = fopen('ip.txt', 'a');
fwrite($fp, "\e[1;34m IP: \e[1;36m" . $ipaddress);
fwrite($fp, "\e[1;34m User-Agent: \e[1;36m" . $_SERVER['HTTP_USER_AGENT']);
fclose($fp);
